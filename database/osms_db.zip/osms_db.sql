-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2021 at 07:50 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `osms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_adminlogin`
--

CREATE TABLE `tbl_adminlogin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `admin_email` varchar(60) COLLATE utf8_bin NOT NULL,
  `admin_password` varchar(60) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_adminlogin`
--

INSERT INTO `tbl_adminlogin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Admin Kumar', 'admin@gmail.com', '12345'),
(2, 'ravi', 'ravi@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assets`
--

CREATE TABLE `tbl_assets` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `product_dop` date NOT NULL,
  `product_available` int(11) NOT NULL,
  `product_total` int(11) NOT NULL,
  `product_originalcost` int(11) NOT NULL,
  `product_sellingcost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_assets`
--

INSERT INTO `tbl_assets` (`product_id`, `product_name`, `product_dop`, `product_available`, `product_total`, `product_originalcost`, `product_sellingcost`) VALUES
(1, 'Keyboard', '2018-10-03', -5, 10, 400, 500),
(3, 'Mouse', '2018-10-02', -12, 30, 500, 600);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assignwork`
--

CREATE TABLE `tbl_assignwork` (
  `rno` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `request_info` text COLLATE utf8_bin NOT NULL,
  `request_desc` text COLLATE utf8_bin NOT NULL,
  `requester_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_add1` text COLLATE utf8_bin NOT NULL,
  `requester_add2` text COLLATE utf8_bin NOT NULL,
  `requester_city` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_state` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_zip` int(11) NOT NULL,
  `requester_email` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_mobile` bigint(11) NOT NULL,
  `assign_tech` varchar(60) COLLATE utf8_bin NOT NULL,
  `assign_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_assignwork`
--

INSERT INTO `tbl_assignwork` (`rno`, `request_id`, `request_info`, `request_desc`, `requester_name`, `requester_add1`, `requester_add2`, `requester_city`, `requester_state`, `requester_zip`, `requester_email`, `requester_mobile`, `assign_tech`, `assign_date`) VALUES
(1, 2, 'Laptop', 'My laptop is not work proper', 'ASHISH YADAV', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'Dwarikaganj', 'KUREBHAR', 'UTTAR PRADESH', 228125, 'raviyadav2017sln@gmail.com', 7355982725, 'Ravi Yadav', '2021-05-06'),
(2, 3, 'Laptop', 'My laptop is not work proper', 'Anoop Jaiswal', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'Dwarikaganj', 'KUREBHAR', 'UTTAR PRADESH', 228125, 'raviyadav2017sln@gmail.com', 7355982725, 'Golu', '2021-05-06'),
(5, 8, 'car', 'car is not riding', 'Vandna', '', 'Sultanpur', 'KUREBHAR', 'UTTAR PRADESH', 228125, 'raviyadav2017sln@gmail.com', 7355982725, 'Ritika', '2021-05-14'),
(6, 7, 'bike', 'bike not riding', 'Vikas Yadav', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'dwarikaganj', 'KUREBHAR', 'UTTAR PRADESH', 228125, 'raviyadav2017sln@gmail.com', 7355982725, 'Golu', '2021-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `customer_address` varchar(60) COLLATE utf8_bin NOT NULL,
  `customer_product_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `customer_product_quantity` int(11) NOT NULL,
  `customer_product_each` int(11) NOT NULL,
  `customer_product_total` int(11) NOT NULL,
  `customer_product_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customer_id`, `customer_name`, `customer_address`, `customer_product_name`, `customer_product_quantity`, `customer_product_each`, `customer_product_total`, `customer_product_date`) VALUES
(1, 'ASHISH YADAV', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'Mouse', 30, 600, 500, '2021-05-14'),
(2, 'RAVI YADAV', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'Keyboard', 8, 500, 1000, '2021-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_submitrequest`
--

CREATE TABLE `tbl_submitrequest` (
  `request_id` int(11) NOT NULL,
  `request_info` text COLLATE utf8_bin NOT NULL,
  `request_desc` text COLLATE utf8_bin NOT NULL,
  `requester_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_add1` text COLLATE utf8_bin NOT NULL,
  `requester_add2` text COLLATE utf8_bin NOT NULL,
  `requester_city` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_state` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_pin` int(11) NOT NULL,
  `requester_email` varchar(60) COLLATE utf8_bin NOT NULL,
  `requester_mobile` bigint(11) NOT NULL,
  `request_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_submitrequest`
--

INSERT INTO `tbl_submitrequest` (`request_id`, `request_info`, `request_desc`, `requester_name`, `requester_add1`, `requester_add2`, `requester_city`, `requester_state`, `requester_pin`, `requester_email`, `requester_mobile`, `request_date`) VALUES
(5, 'Electronic Fan', 'Fan is not work properly', 'Shyam Veer', '201 SARAI GOKUL POST KANOULI DIST SULTANPUR PIN 228125', 'Dwarikaganj', 'KUREBHAR', 'UTTAR PRADESH', 228125, 'raviyadav2017sln@gmail.com', 7355982725, '2021-05-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_technician`
--

CREATE TABLE `tbl_technician` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `emp_city` varchar(60) COLLATE utf8_bin NOT NULL,
  `emp_mobile` bigint(11) NOT NULL,
  `emp_email` varchar(60) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_technician`
--

INSERT INTO `tbl_technician` (`emp_id`, `emp_name`, `emp_city`, `emp_mobile`, `emp_email`) VALUES
(14, 'yadav', 'faizabad', 6977899696, 'raviyadav2018sln@gmail.com'),
(15, 'Mukesh', 'Noida', 67799969986, 'mukesh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userlogin`
--

CREATE TABLE `tbl_userlogin` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(60) COLLATE utf8_bin NOT NULL,
  `user_email` varchar(60) COLLATE utf8_bin NOT NULL,
  `user_password` varchar(60) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_userlogin`
--

INSERT INTO `tbl_userlogin` (`user_id`, `user_name`, `user_email`, `user_password`) VALUES
(1, 'ravi', 'raviyadav2017sln@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_adminlogin`
--
ALTER TABLE `tbl_adminlogin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_assets`
--
ALTER TABLE `tbl_assets`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_assignwork`
--
ALTER TABLE `tbl_assignwork`
  ADD PRIMARY KEY (`rno`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `tbl_submitrequest`
--
ALTER TABLE `tbl_submitrequest`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `tbl_technician`
--
ALTER TABLE `tbl_technician`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tbl_userlogin`
--
ALTER TABLE `tbl_userlogin`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_adminlogin`
--
ALTER TABLE `tbl_adminlogin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_assets`
--
ALTER TABLE `tbl_assets`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_assignwork`
--
ALTER TABLE `tbl_assignwork`
  MODIFY `rno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_submitrequest`
--
ALTER TABLE `tbl_submitrequest`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_technician`
--
ALTER TABLE `tbl_technician`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_userlogin`
--
ALTER TABLE `tbl_userlogin`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
